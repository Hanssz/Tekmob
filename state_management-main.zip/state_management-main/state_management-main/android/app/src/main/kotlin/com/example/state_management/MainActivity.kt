package com.example.state_management

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
