import 'package:flutter/material.dart';

// NIM: 2100016036
// Nama: Hanif Amrin Rasyada

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'Hanif Amrin Rasyada - Layouts',
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark(),
        home: Scaffold(
          appBar: AppBar(
            title: const Text("Hanif Amrin Rasyada - Row"),
          ),
          body: const Row(
            children: <Widget>[
              Text("Text 1"),
              Text("Text 2"),
              Text("Text 3"),
            ],
          ),
        ));
  }
}
